package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel

class ScoreViewModel : ViewModel() {

    // Tracks the score for Team A
    var scoreTeamA = 0

    // Tracks the score for Team B
    var scoreTeamB = 0

    override fun onCleared() {
        Log.d("TAG:ScoreViewModel","onCleared")
        super.onCleared()
    }
}